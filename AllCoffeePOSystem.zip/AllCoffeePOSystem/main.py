# from kivy.app import App
# from kivy.uix.tabbedpanel import TabbedPanel

# from sell_tab import SellTab
# from manage_tab import ManageTab
# from statistics_tab import StatisticsTab

# class MyApp(App):
#     def build(self):
#         tab_panel = TabbedPanel(do_default_tab=False)
#         tab_panel.add_widget(SellTab())
#         tab_panel.add_widget(StatisticsTab())
#         tab_panel.add_widget(ManageTab())
#         return tab_panel

# if __name__ == '__main__':
#     MyApp().run()

from kivy.app import App
from kivy.uix.tabbedpanel import TabbedPanel
from kivy.uix.boxlayout import BoxLayout
from kivy.core.text import LabelBase
from kivy.uix.gridlayout import GridLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.scrollview import ScrollView
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.utils import get_color_from_hex  # <--- Добавленная строка

from sell_tab import SellTab
from manage_tab import ManageTab
from statistics_tab import StatisticsTab



class MyApp(App):
    def build(self):
        # Загружаем шрифт Monospace
        LabelBase.register(name='roboto', fn_regular='Roboto-Black.ttf')

        tab_panel = TabbedPanel(do_default_tab=False)
        tab_panel.add_widget(SellTab())
        tab_panel.add_widget(StatisticsTab())
        tab_panel.add_widget(ManageTab())

        # Создаем главный контейнер с горизонтальным BoxLayout
        main_layout = BoxLayout(orientation='horizontal')

        # Левая часть
        left_layout = BoxLayout(orientation='vertical', size_hint_x=0.5)

        # Создаем ScrollView
        scroll_view = ScrollView(size_hint=(None, None), size=(Window.width, Window.height - dp(50)))
        # Добавляем GridLayout для кнопок в ScrollView
        buttons_layout = GridLayout(cols=3, spacing=5, size_hint_y=None)

        self.add_buttons_from_csv(buttons_layout)

        # Устанавливаем свойство minimum_height для автоматического обновления высоты GridLayout
        buttons_layout.bind(minimum_height=buttons_layout.setter('height'))

        # Добавляем GridLayout в ScrollView
        scroll_view.add_widget(buttons_layout)

        # Добавляем ScrollView в левую часть
        left_layout.add_widget(scroll_view)

        # Правая часть
        right_layout = BoxLayout(orientation='vertical', size_hint_x=0.5)
        right_layout.add_widget(Label(text='Правая часть', color=get_color_from_hex('#000000')))

        # Добавляем левую и правую части в главный контейнер
        main_layout.add_widget(left_layout)
        main_layout.add_widget(right_layout)

        # Добавляем главный контейнер на вкладку
        tab_panel.add_widget(main_layout)

        return tab_panel

    def add_buttons_from_csv(self, layout):
        # Ваш код для добавления кнопок из CSV
        pass

if __name__ == '__main__':
    MyApp().run()
