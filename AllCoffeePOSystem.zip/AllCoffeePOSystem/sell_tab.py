from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.uix.button import Button

from kivy.uix.label import Label
from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.uix.boxlayout import BoxLayout
from kivy.graphics import Color, Rectangle
from kivy.utils import get_color_from_hex

class SellTab(TabbedPanelItem):
    def __init__(self, **kwargs):
        super(SellTab, self).__init__(text='Sell Tab')

        # Создаем главный контейнер с горизонтальным BoxLayout
        main_layout = BoxLayout(orientation='horizontal')

        # Устанавливаем цвет фона
        with main_layout.canvas.before:
            Color(*get_color_from_hex('#ffffff'))
            self.rect = Rectangle(size=main_layout.size, pos=main_layout.pos)

        # Обновляем цвет фона при изменении размеров
        main_layout.bind(size=self.update_background, pos=self.update_background)

        # Левая часть
        left_layout = BoxLayout(orientation='vertical')
        left_layout.add_widget(Label(text='Левая часть', color=get_color_from_hex('#000000')))

        # Правая часть
        right_layout = BoxLayout(orientation='vertical')
        right_layout.add_widget(Label(text='Правая часть', color=get_color_from_hex('#000000')))

        # Добавляем левую и правую части в главный контейнер
        main_layout.add_widget(left_layout)
        main_layout.add_widget(right_layout)

        # Добавляем главный контейнер на вкладку
        self.add_widget(main_layout)

    def update_background(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size


#from kivy.uix.gridlayout import GridLayout
import csv
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.graphics import Color, Rectangle
from kivy.utils import get_color_from_hex
from kivy.uix.scrollview import ScrollView
from kivy.core.window import Window
from kivy.metrics import dp
from kivy.uix.gridlayout import GridLayout

class SellTab(TabbedPanelItem):
    def __init__(self, **kwargs):
        super(SellTab, self).__init__(text='Sell Tab')

        # Создаем главный контейнер с горизонтальным BoxLayout
        main_layout = BoxLayout(orientation='horizontal')

        # Устанавливаем цвет фона
        with main_layout.canvas.before:
            Color(*get_color_from_hex('#ffffff'))
            self.rect = Rectangle(size=main_layout.size, pos=main_layout.pos)

        # Обновляем цвет фона при изменении размеров
        main_layout.bind(size=self.update_background, pos=self.update_background)

        # Левая часть
        left_layout = BoxLayout(orientation='vertical', size_hint_x=0.5)

        # Создаем ScrollView
        self.scroll_view = ScrollView(size_hint=(None, None), size=(Window.width, Window.height - dp(50)))
        # Добавляем GridLayout для кнопок в ScrollView
        self.buttons_layout = GridLayout(cols=3, spacing=5, size_hint_y=None)

        self.add_buttons_from_csv(self.buttons_layout)

        # Устанавливаем свойство minimum_height для автоматического обновления высоты GridLayout
        self.buttons_layout.bind(minimum_height=self.buttons_layout.setter('height'))

        # Добавляем GridLayout в ScrollView
        self.scroll_view.add_widget(self.buttons_layout)

        # Добавляем ScrollView в левую часть
        left_layout.add_widget(self.scroll_view)

        # Правая часть
        right_layout = BoxLayout(orientation='vertical', size_hint_x=0.5)
        right_layout.add_widget(Label(text='Правая часть', color=get_color_from_hex('#000000')))

        # Добавляем левую и правую части в главный контейнер
        main_layout.add_widget(left_layout)
        main_layout.add_widget(right_layout)

        # Добавляем главный контейнер на вкладку
        self.add_widget(main_layout)

        # Добавляем обработчик изменения размера окна
        Window.bind(on_resize=self.on_resize)

    def update_background(self, instance, value):
        self.rect.pos = instance.pos
        self.rect.size = instance.size

    def add_buttons_from_csv(self, layout):
        # Читаем данные из CSV-файла
        with open('products.csv', 'r', newline='') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                product_name = row['Название']
                product_price = row['Цена']

                # Создаем кнопку с информацией из CSV
                button_text = f'{product_name}\nЦена: {product_price} руб.'
                button = Button(text=button_text, size_hint_y=None, height=60, background_color=get_color_from_hex('#00ff00'))
                button.bind(on_press=self.on_button_press)

                # Добавляем кнопку в макет
                layout.add_widget(button)

    def on_button_press(self, instance):
        # Обработка нажатия на кнопку
        button_text = instance.text.split('\n')
        product_name = button_text[0]
        product_price = float(button_text[1].split('Цена: ')[1].split(' руб.')[0])

        # Ваш код для обработки нажатия на кнопку
        print(f'Выбран продукт: {product_name}, Цена: {product_price} руб.')

    def on_resize(self, instance, width, height):
        # Обновление размеров ScrollView при изменении размера окна
        self.scroll_view.size = (width * 0.5, height - dp(50))
