from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.uix.button import Button

class StatisticsTab(TabbedPanelItem):
    def __init__(self, **kwargs):
        super(StatisticsTab, self).__init__(text='Statistics Tab')
        self.add_widget(Button(text='Content of Statistics Tab'))
