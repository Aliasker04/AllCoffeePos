import csv

from kivy.uix.tabbedpanel import TabbedPanelItem
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.utils import get_color_from_hex

class ManageTab(TabbedPanelItem):
    def __init__(self, **kwargs):
        super(ManageTab, self).__init__(text='Manage Tab')

        # Создаем BoxLayout для удобного размещения виджетов
        layout = BoxLayout(orientation='vertical')

        # Поля ввода для названия и цены продукта
        self.name_input = TextInput(hint_text='Введите название продукта', multiline=False, font_size=20)
        layout.add_widget(self.name_input)

        self.price_input = TextInput(hint_text='Введите цену продукта', input_type='number', multiline=False, font_size=20)
        layout.add_widget(self.price_input)

        # Горизонтальный BoxLayout для кнопок
        buttons_layout = BoxLayout(orientation='horizontal', size_hint_y=0.5)

        # Кнопка для добавления продукта
        add_button = Button(text='Добавить продукт', background_color=get_color_from_hex('#00ff00'))
        add_button.bind(on_press=self.add_product)
        buttons_layout.add_widget(add_button)

        # Кнопка для удаления продукта
        delete_button = Button(text='Удалить продукт', background_color=get_color_from_hex('#ff0000'))
        delete_button.bind(on_press=self.delete_product)
        buttons_layout.add_widget(delete_button)

        layout.add_widget(buttons_layout)

        self.add_widget(layout)

        # Установка фона для вкладки
        self.background_color = (1, 1, 1, 1)  # (R, G, B, A)

    def add_product(self, instance):
        # Получаем текст из полей ввода
        product_name = self.name_input.text.strip()  # Удаляем пробелы в начале и конце
        product_price = self.price_input.text

        if product_name and product_price:
            try:
                # Пробуем преобразовать введенную цену в число
                product_price = float(product_price)

                # Добавляем данные в CSV-файл
                with open('products.csv', 'a', newline='') as csvfile:
                    fieldnames = ['Название', 'Цена']
                    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

                    # Если файл пустой, записываем заголовки
                    if csvfile.tell() == 0:
                        writer.writeheader()

                    # Записываем данные продукта
                    writer.writerow({'Название': product_name, 'Цена': product_price})

                print(f'Добавлен продукт: {product_name}, Цена: {product_price}')

                # Очищаем поля ввода
                self.name_input.text = ''
                self.price_input.text = ''
            except ValueError:
                print('Введите корректную цену продукта.')
        else:
            print('Введите название и цену продукта.')

    def delete_product(self, instance):
        # Получаем текст из поля ввода
        product_name = self.name_input.text.strip()  # Удаляем пробелы в начале и конце

        if product_name:
            # Читаем данные из CSV-файла
            products = []
            with open('products.csv', 'r', newline='') as csvfile:
                reader = csv.DictReader(csvfile)
                for row in reader:
                    products.append(row)

            # Проверяем, есть ли продукт с указанным названием
            product_found = False
            for product in products:
                if product['Название'] == product_name:
                    product_found = True
                    products.remove(product)
                    break

            if product_found:
                # Перезаписываем данные в CSV-файл
                with open('products.csv', 'w', newline='') as csvfile:
                    fieldnames = ['Название', 'Цена']
                    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
                    writer.writeheader()
                    for product in products:
                        writer.writerow(product)

                print(f'Продукт с названием "{product_name}" удален.')
                # Очищаем поле ввода
                self.name_input.text = ''
            else:
                print(f'Продукт с названием "{product_name}" не найден. Пожалуйста, введите существующее название продукта.')
        else:
            print('Введите название продукта для удаления.')
